# Nexon Android Project v1.8.0

Native Android game launcher with a compact floating HUD and optional touch-through visual overlays.

## v1.8.0 changes
- Added a full-screen transparent visual overlay that can appear above other apps when enabled.
- Added independent `NV` and crosshair toggle chips to the main floating HUD.
- Night Vision overlay now has 14 colored tint presets and adjustable intensity.
- Added a 10-shape crosshair studio with 12 color choices and adjustable size.
- Crosshair and tint layers are drawn in a non-touchable overlay window so taps are passed to the game underneath, subject to Android's overlay security rules and individual game restrictions.
- Closing the HUD stops both visual layers.
- Removed the earlier in-app-only color filter and crosshair preview behavior as the primary feature.
- Kept application ID `com.volt.gaming` and incremented version code to 10, version name to 1.8.0.

## Important limitations
- The Night Vision feature is a translucent color-tint overlay. It is **not** a true pixel-by-pixel color grade of another app's rendered frames; ordinary Android apps cannot apply a system-wide color matrix to another game's display without special system-level access or a heavier screen-capture pipeline.
- The crosshair is a static customizable reticle, not enemy detection, tracking, or automated aiming.
- Some games may block overlays or disallow third-party overlays in their rules. The app does not bypass those restrictions.
- Android does not expose another game's live FPS to ordinary apps, so Nexon continues to show `N/A` rather than inventing a value.

## Build
Use the repository's existing GitHub Actions Android build workflow. The project folder is `VOLTGaming/`.
