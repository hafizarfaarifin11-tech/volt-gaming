# Nexon Android Project v1.6

Native Android launcher and compact floating gaming HUD.

## v1.6 changes
- Removed the old automated-touch feature and all related Accessibility Service permissions and configuration.
- Replaced the HUD `+` control with an `NV` button that toggles a subtle green screen tint.
- Added Crosshair Studio to the Nexon launcher: choose style, color, and size with an in-app preview.
- Crosshair customization is preview-only inside Nexon; it is not displayed over other apps or games.
- Kept the existing package/application ID `com.volt.gaming` so a correctly signed update can replace the previous build.
- Version code 7, version name 1.6.

## Notes
Night Vision is a cosmetic green tint, not an actual low-light camera mode or enemy detector. Android does not expose another game's live FPS to ordinary apps, so Nexon continues to show `N/A` rather than inventing a value.

## Build
Use the repository's existing GitHub Actions Android build workflow. The project folder is `VOLTGaming/`.
