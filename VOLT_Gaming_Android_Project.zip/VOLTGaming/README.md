# VOLT Gaming — Native Android Starter

Minimal dark Android launcher starter written in Kotlin. The project can be built in the cloud; Android Studio is not required on your phone.

## Included features
- Minimal dark dashboard
- Device-wide RAM usage estimate
- Battery temperature (not CPU temperature)
- Network connection type
- Approximate latency probe to Cloudflare DNS (1.1.1.1)
- Launchable installed-app list with OPEN buttons
- Clear notice about the Android FPS access limitation

## Build from an Android phone (no Android Studio)
1. Create a GitHub repository in your browser.
2. In that repository, create the file `.github/workflows/build-apk.yml` and paste the workflow from `BUILD_WORKFLOW_COPY.txt` (or use the separate workflow file supplied with this project).
3. Upload `VOLT_Gaming_Android_Project.zip` to the repository root.
4. Open the repository's **Actions** tab and open **Build VOLT Gaming APK**. The workflow can also be started manually with **Run workflow**.
5. When the run succeeds, download the `VOLT-Gaming-debug-apk` artifact from the run page. Extract it and install `app-debug.apk`.

The workflow installs JDK, Android SDK, and Gradle on GitHub-hosted runners, then compiles the APK and saves it as an artifact.

## Technical notes
- `compileSdk` and `targetSdk` are 35 for a stable build toolchain; Android 16 can install apps targeting API 35. This does not claim full Android 16 behavior verification.
- A normal third-party app cannot universally read another game's live FPS on modern Android. Use the phone's built-in game overlay for per-game FPS when supported.
- Ping is an approximate reachability measurement, not the ping to a specific game server. Some networks block the probe.
- RAM is device-wide, not per-game. Battery temperature is not CPU temperature.
- The `QUERY_ALL_PACKAGES` permission supports the app-library use case; Play Store distribution may require policy review.
