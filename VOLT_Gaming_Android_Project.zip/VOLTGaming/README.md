# Nexon Android Project v1.7.1

Native Android launcher and compact floating gaming HUD.

## v1.7.1 changes
- Removed the old green-only screen tint button from the floating HUD.
- Added Display Filters with Night Green, Monochrome, High Contrast, Cool, and Warm presets, plus adjustable intensity and an ON/OFF switch.
- Display filters use Android color-matrix rendering and apply to Nexon's own launcher UI and preview only. They do not recolor another app or game.
- Added an ON/OFF switch for the Crosshair Studio preview, while retaining style, color, and size controls.
- Crosshair customization remains a preview inside Nexon. It is not displayed over other apps or games.
- Kept the existing package/application ID `com.volt.gaming` so a correctly signed update can replace the previous build.
- Version code 8, version name 1.7.

## Notes
Android does not expose another game's live FPS to ordinary apps, so Nexon continues to show `N/A` rather than inventing a value. No enemy detection, automated touch, or game-targeting feature is included.

## Build
Use the repository's existing GitHub Actions Android build workflow. The project folder is `VOLTGaming/`.
