# Nexon v1.3

A lightweight Android game launcher and floating device monitor.

## Features
- Landscape-first launcher interface.
- Installed app/game launcher list.
- Floating horizontal HUD with system RAM, battery temperature, and TCP connection latency.
- FPS is marked unavailable because standard Android apps cannot read another game's live FPS without system/OEM support. The app intentionally does not fabricate an FPS value.

## Build
Use the included GitHub Actions workflow instructions. Keep the existing application ID `com.volt.gaming` so this release can update the previous VOLT installation rather than install as a separate app.
