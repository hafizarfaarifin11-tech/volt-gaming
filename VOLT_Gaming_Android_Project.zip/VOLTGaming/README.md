# Nexon v1.4

A lightweight Android game launcher and floating device monitor.

## What's new in v1.4
- Launcher content now applies Android system-bar insets so navigation controls do not cover the game OPEN actions on Android 15/16.
- Floating HUD has a `+` button that opens the Dual Macro editor.
- Dual Macro provides a draggable trigger circle and a draggable tap-target circle. Trigger size and tap interval are configurable.
- Macro taps are sent only while the user holds the trigger. Release the trigger to stop; the editor also provides a Stop button.
- Macro uses an AccessibilityService with gesture permission and does not read screen contents. The service is off until the user explicitly enables it in Android Accessibility settings.
- HUD continues to show RAM, battery temperature, TCP connection latency, and FPS as N/A when Android does not expose another game's FPS.

## Important
Some games prohibit automated touch macros and may apply account penalties. Use this feature only where macros are permitted. Android may require the user to allow restricted settings before enabling the accessibility service for a sideloaded app.

## Build
Keep the existing application ID `com.volt.gaming` so this release can update the earlier Nexon/VOLT installation rather than install as a separate app. Build with the existing GitHub Actions workflow.
