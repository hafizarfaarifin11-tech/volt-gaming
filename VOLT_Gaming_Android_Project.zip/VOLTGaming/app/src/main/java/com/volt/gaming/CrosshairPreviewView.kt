package com.volt.gaming

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

object CrosshairPalette {
    val colors = intArrayOf(
        Color.rgb(90, 255, 130),
        Color.rgb(70, 220, 255),
        Color.rgb(255, 92, 92),
        Color.WHITE,
        Color.rgb(255, 220, 70)
    )
    val names = listOf("Neon Green", "Cyan", "Red", "White", "Yellow")
}

/** Preview-only crosshair. It is intentionally part of Nexon's own screen, not a game overlay. */
class CrosshairPreviewView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var style = 0
    private var colorIndex = 0
    private var sizeDp = 28
    private var previewEnabled = true

    fun setSettings(newStyle: Int, newColorIndex: Int, newSizeDp: Int, enabled: Boolean = true) {
        style = newStyle.coerceIn(0, 3)
        colorIndex = newColorIndex.coerceIn(CrosshairPalette.colors.indices)
        sizeDp = newSizeDp.coerceIn(12, 48)
        previewEnabled = enabled
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(15, 19, 28))
        if (!previewEnabled) {
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(157, 166, 183)
            paint.textSize = 11f * resources.displayMetrics.density
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("CROSSHAIR PREVIEW OFF", width / 2f, height / 2f + paint.textSize / 3f, paint)
            return
        }
        val cx = width / 2f
        val cy = height / 2f
        val radius = sizeDp * resources.displayMetrics.density / 2f
        val gap = radius * 0.28f
        paint.color = CrosshairPalette.colors[colorIndex]
        paint.strokeWidth = (2.2f * resources.displayMetrics.density).coerceAtLeast(1.5f)
        paint.strokeCap = Paint.Cap.ROUND
        paint.style = Paint.Style.STROKE

        when (style) {
            0 -> { // Four separated arms
                canvas.drawLine(cx - radius, cy, cx - gap, cy, paint)
                canvas.drawLine(cx + gap, cy, cx + radius, cy, paint)
                canvas.drawLine(cx, cy - radius, cx, cy - gap, paint)
                canvas.drawLine(cx, cy + gap, cx, cy + radius, paint)
            }
            1 -> { // Center dot
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, (radius * 0.23f).coerceAtLeast(2f), paint)
            }
            2 -> { // Ring and center dot
                canvas.drawCircle(cx, cy, radius * 0.72f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, (radius * 0.14f).coerceAtLeast(2f), paint)
            }
            else -> { // Simple continuous plus
                canvas.drawLine(cx - radius, cy, cx + radius, cy, paint)
                canvas.drawLine(cx, cy - radius, cx, cy + radius, paint)
            }
        }
    }
}
