package com.volt.gaming

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

object CrosshairPalette {
    val colors = intArrayOf(
        Color.rgb(90, 255, 130), Color.rgb(70, 220, 255), Color.rgb(255, 92, 92),
        Color.WHITE, Color.rgb(255, 220, 70), Color.rgb(255, 130, 45),
        Color.rgb(196, 104, 255), Color.rgb(255, 86, 190), Color.rgb(174, 255, 55),
        Color.rgb(90, 150, 255), Color.rgb(255, 190, 120), Color.rgb(20, 20, 20)
    )
    val names = listOf(
        "Neon Green", "Cyan", "Red", "White", "Yellow", "Orange",
        "Purple", "Pink", "Lime", "Sky Blue", "Peach", "Black"
    )
    val styles = listOf("Classic", "Dot", "Ring", "Plus", "X", "Ring + Dot", "T Shape", "Diamond", "Four Dots", "Brackets")
}

/** Shared renderer for the Nexon preview and the transparent in-game overlay. */
object CrosshairRenderer {
    fun draw(canvas: Canvas, cx: Float, cy: Float, style: Int, colorIndex: Int, sizeDp: Int, density: Float, paint: Paint) {
        val radius = sizeDp.coerceIn(12, 64) * density / 2f
        val gap = radius * 0.28f
        val color = CrosshairPalette.colors[colorIndex.coerceIn(CrosshairPalette.colors.indices)]
        paint.color = color
        paint.strokeWidth = (2.2f * density).coerceAtLeast(1.5f)
        paint.strokeCap = Paint.Cap.ROUND
        paint.style = Paint.Style.STROKE
        paint.shader = null

        when (style.coerceIn(CrosshairPalette.styles.indices)) {
            0 -> {
                canvas.drawLine(cx - radius, cy, cx - gap, cy, paint)
                canvas.drawLine(cx + gap, cy, cx + radius, cy, paint)
                canvas.drawLine(cx, cy - radius, cx, cy - gap, paint)
                canvas.drawLine(cx, cy + gap, cx, cy + radius, paint)
            }
            1 -> { paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, (radius * 0.23f).coerceAtLeast(2f), paint) }
            2 -> canvas.drawCircle(cx, cy, radius * 0.72f, paint)
            3 -> {
                canvas.drawLine(cx - radius, cy, cx + radius, cy, paint)
                canvas.drawLine(cx, cy - radius, cx, cy + radius, paint)
            }
            4 -> {
                canvas.drawLine(cx - radius * .72f, cy - radius * .72f, cx + radius * .72f, cy + radius * .72f, paint)
                canvas.drawLine(cx + radius * .72f, cy - radius * .72f, cx - radius * .72f, cy + radius * .72f, paint)
            }
            5 -> {
                canvas.drawCircle(cx, cy, radius * .72f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, (radius * .13f).coerceAtLeast(2f), paint)
            }
            6 -> {
                canvas.drawLine(cx - radius, cy, cx + radius, cy, paint)
                canvas.drawLine(cx, cy, cx, cy + radius, paint)
            }
            7 -> {
                val diamond = Path().apply {
                    moveTo(cx, cy - radius); lineTo(cx + radius, cy)
                    lineTo(cx, cy + radius); lineTo(cx - radius, cy); close()
                }
                canvas.drawPath(diamond, paint)
            }
            8 -> {
                paint.style = Paint.Style.FILL
                val dot = (radius * .12f).coerceAtLeast(2f)
                canvas.drawCircle(cx - gap, cy - gap, dot, paint)
                canvas.drawCircle(cx + gap, cy - gap, dot, paint)
                canvas.drawCircle(cx - gap, cy + gap, dot, paint)
                canvas.drawCircle(cx + gap, cy + gap, dot, paint)
            }
            else -> {
                val arm = radius * .58f
                val inner = radius * .18f
                canvas.drawLine(cx - radius, cy - radius, cx - inner, cy - radius, paint)
                canvas.drawLine(cx - radius, cy - radius, cx - radius, cy - inner, paint)
                canvas.drawLine(cx + radius, cy - radius, cx + inner, cy - radius, paint)
                canvas.drawLine(cx + radius, cy - radius, cx + radius, cy - inner, paint)
                canvas.drawLine(cx - radius, cy + radius, cx - inner, cy + radius, paint)
                canvas.drawLine(cx - radius, cy + radius, cx - radius, cy + inner, paint)
                canvas.drawLine(cx + radius, cy + radius, cx + inner, cy + radius, paint)
                canvas.drawLine(cx + radius, cy + radius, cx + radius, cy + inner, paint)
            }
        }
    }
}

/** Preview inside Nexon. */
class CrosshairPreviewView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var style = 0
    private var colorIndex = 0
    private var sizeDp = 28

    fun setSettings(newStyle: Int, newColorIndex: Int, newSizeDp: Int) {
        style = newStyle.coerceIn(CrosshairPalette.styles.indices)
        colorIndex = newColorIndex.coerceIn(CrosshairPalette.colors.indices)
        sizeDp = newSizeDp.coerceIn(12, 64)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(15, 19, 28))
        CrosshairRenderer.draw(canvas, width / 2f, height / 2f, style, colorIndex, sizeDp, resources.displayMetrics.density, paint)
    }
}

/** Transparent, touch-through reticle drawn above the currently open game. */
class CrosshairOverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var style = 0
    private var colorIndex = 0
    private var sizeDp = 28

    init { setBackgroundColor(Color.TRANSPARENT) }

    fun configure(newStyle: Int, newColorIndex: Int, newSizeDp: Int) {
        style = newStyle.coerceIn(CrosshairPalette.styles.indices)
        colorIndex = newColorIndex.coerceIn(CrosshairPalette.colors.indices)
        sizeDp = newSizeDp.coerceIn(12, 64)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        CrosshairRenderer.draw(canvas, width / 2f, height / 2f, style, colorIndex, sizeDp, resources.displayMetrics.density, paint)
    }
}
