package com.volt.gaming

import android.app.Activity
import android.os.Bundle
import android.os.BatteryManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Debug
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.InetAddress
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 14, 19)
    private val panel = Color.rgb(23, 27, 35)
    private val accent = Color.rgb(126, 156, 255)
    private val muted = Color.rgb(157, 166, 183)
    private lateinit var ramValue: TextView
    private lateinit var tempValue: TextView
    private lateinit var pingValue: TextView
    private lateinit var networkValue: TextView
    private lateinit var gameList: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        buildUi()
        refreshStats()
        loadGames()
        measurePing()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "VOLT"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        val sub = TextView(this).apply {
            text = "  GAMING"
            textSize = 12f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
        }
        top.addView(brand)
        top.addView(sub)
        page.addView(top)
        page.addView(text("Your gaming space", 14f, muted).apply {
            setPadding(0, dp(5), 0, dp(22))
        })

        page.addView(sectionTitle("DEVICE OVERVIEW"))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ramValue = addStat(row1, "RAM USED", "Loading…")
        tempValue = addStat(row1, "BATTERY TEMP", "Loading…")
        pingValue = addStat(row2, "PING", "Checking…")
        networkValue = addStat(row2, "NETWORK", networkType())
        stats.addView(row1)
        stats.addView(row2)
        page.addView(stats)

        page.addView(sectionTitle("PERFORMANCE"))
        val perf = card()
        perf.addView(text("FPS MONITOR", 13f, Color.WHITE, true))
        perf.addView(text("Not available to ordinary third-party apps", 17f, accent, true).apply {
            setPadding(0, dp(9), 0, dp(4))
        })
        perf.addView(text("Android does not expose another game's live FPS through a normal app API. Use your phone's built-in game dashboard or supported system overlay for per-game FPS.", 12f, muted))
        page.addView(perf)

        page.addView(sectionTitle("GAME LIBRARY"))
        val reload = TextView(this).apply {
            text = "Refresh list"
            textSize = 12f
            setTextColor(accent)
            gravity = Gravity.END
            setPadding(0, 0, 0, dp(10))
            setOnClickListener { loadGames() }
        }
        page.addView(reload)
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(gameList)

        page.addView(text("VOLT Gaming  •  v1.0", 11f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        })
    }

    private fun addStat(row: LinearLayout, label: String, initial: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(15), dp(10), dp(15))
            setBackgroundColor(panel)
        }
        val lp = LinearLayout.LayoutParams(0, dp(94), 1f)
        lp.setMargins(0, 0, dp(8), dp(8))
        row.addView(box, lp)
        box.addView(text(label, 10f, muted, true))
        val value = text(initial, 20f, Color.WHITE, true).apply {
            setPadding(0, dp(10), 0, 0)
        }
        box.addView(value)
        return value
    }

    private fun sectionTitle(s: String): TextView = text(s, 11f, muted, true).apply {
        setPadding(0, dp(18), 0, dp(10))
        letterSpacing = 0.12f
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun refreshStats() {
        val mem = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo()
        mem.getMemoryInfo(info)
        val used = info.totalMem - info.availMem
        ramValue.text = "${used / (1024 * 1024)} MB"
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        tempValue.text = if (temp >= 0) String.format("%.1f°C", temp / 10f) else "N/A"
        networkValue.text = networkType()
    }

    private fun networkType(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "Offline"
        val caps = cm.getNetworkCapabilities(network) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }
    }

    private fun measurePing() {
        executor.execute {
            val result = try {
                val start = System.nanoTime()
                InetAddress.getByName("1.1.1.1").isReachable(1800)
                ((System.nanoTime() - start) / 1_000_000).toInt().toString() + " ms"
            } catch (_: Exception) { "N/A" }
            runOnUiThread {
                pingValue.text = result
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun loadGames() {
        gameList.removeAllViews()
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        if (apps.isEmpty()) {
            gameList.addView(card().apply {
                addView(text("No launchable apps found.", 14f, Color.WHITE))
                addView(text("Install a game, then tap Refresh list.", 12f, muted))
            })
            return
        }

        apps.forEach { app ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(panel)
            }
            val icon = ImageView(this).apply {
                setImageDrawable(pm.getApplicationIcon(app))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            item.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
            val name = text(pm.getApplicationLabel(app).toString(), 14f, Color.WHITE, true)
            val nameLp = LinearLayout.LayoutParams(0, -2, 1f).apply {
                leftMargin = dp(12)
            }
            item.addView(name, nameLp)
            val launch = TextView(this).apply {
                text = "OPEN"
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(accent)
                setPadding(dp(12), dp(9), dp(12), dp(9))
                setOnClickListener {
                    pm.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
                }
            }
            item.addView(launch)
            val outer = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }
            gameList.addView(item, outer)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }
}
