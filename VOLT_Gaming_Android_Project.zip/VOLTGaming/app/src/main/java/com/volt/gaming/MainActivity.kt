package com.volt.gaming

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 12, 17)
    private val panel = Color.rgb(22, 26, 35)
    private val accent = Color.rgb(126, 156, 255)
    private val muted = Color.rgb(157, 166, 183)
    private lateinit var ramValue: TextView
    private lateinit var tempValue: TextView
    private lateinit var pingValue: TextView
    private lateinit var networkValue: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var gameList: LinearLayout
    private val visualPrefs by lazy { getSharedPreferences("nexon_visual", Context.MODE_PRIVATE) }
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() { refreshStats(); handler.postDelayed(this, 3000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        loadGames()
    }

    override fun onResume() {
        super.onResume()
        refreshStats(); handler.removeCallbacks(refreshTask); handler.post(refreshTask); updateOverlayStatus()
    }
    override fun onPause() { super.onPause(); handler.removeCallbacks(refreshTask) }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            // Android 15/16 edge-to-edge can place app content behind the navigation bar.
            // Keep the whole launcher (especially OPEN buttons) inside the safe area.
            setOnApplyWindowInsetsListener { view, insets ->
                val insetValues = if (android.os.Build.VERSION.SDK_INT >= 30) {
                    val bars = insets.getInsets(WindowInsets.Type.systemBars())
                    intArrayOf(bars.left, bars.top, bars.right, bars.bottom)
                } else {
                    @Suppress("DEPRECATION")
                    val leftInset = insets.systemWindowInsetLeft
                    @Suppress("DEPRECATION")
                    val topInset = insets.systemWindowInsetTop
                    @Suppress("DEPRECATION")
                    val rightInset = insets.systemWindowInsetRight
                    @Suppress("DEPRECATION")
                    val bottomInset = insets.systemWindowInsetBottom
                    intArrayOf(leftInset, topInset, rightInset, bottomInset)
                }
                val insetLeft = insetValues[0]
                val insetTop = insetValues[1]
                val insetRight = insetValues[2]
                val insetBottom = insetValues[3]
                view.setPadding(dp(18) + insetLeft, dp(12) + insetTop,
                    dp(18) + insetRight, dp(12) + insetBottom)
                insets
            }
        }
        setContentView(root)
        root.requestApplyInsets()

        // Both landscape columns are independently scrollable. Previously only the
        // games column scrolled, leaving the Floating HUD / ENABLE control below
        // the fold on shorter displays.
        val leftScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        root.addView(leftScroll, LinearLayout.LayoutParams(0, -1, 1.08f).apply { rightMargin = dp(12) })
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        leftScroll.addView(left, android.view.ViewGroup.LayoutParams(-1, -2))

        val rightScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        root.addView(rightScroll, LinearLayout.LayoutParams(0, -1, 0.92f))
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, dp(4), dp(8)) }
        rightScroll.addView(right)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("NEXON", 25f, Color.WHITE, true))
        header.addView(text("  GAME HUB", 10f, accent, true))
        left.addView(header)
        left.addView(text("Simple gaming monitor", 12f, muted).apply { setPadding(0, dp(2), 0, dp(12)) })

        left.addView(sectionTitle("LIVE DEVICE STATUS"))
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ramValue = addStat(row1, "▦  SYSTEM RAM", "—")
        tempValue = addStat(row1, "♨  BATTERY TEMP", "—")
        pingValue = addStat(row2, "⌁  TCP PING", "—")
        networkValue = addStat(row2, "◉  NETWORK", "—")
        left.addView(row1); left.addView(row2)
        left.addView(text("Ping tests Cloudflare (1.1.1.1), not the game server. Temperature is battery temperature, not CPU temperature.", 10f, muted))

        left.addView(sectionTitle("FLOATING HUD"))
        val hudRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(panel) }
        val hudText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        hudText.addView(text("Compact gaming overlay", 13f, Color.WHITE, true))
        hudText.addView(text("RAM • temperature • ping • FPS availability", 10f, muted))
        hudRow.addView(hudText, LinearLayout.LayoutParams(0, -2, 1f))
        hudRow.addView(Button(this).apply { text = "ENABLE"; setOnClickListener { enableOverlay() } })
        left.addView(hudRow)
        overlayStatus = text("Overlay permission: checking…", 10f, accent, true).apply { setPadding(0, dp(7), 0, 0) }
        left.addView(overlayStatus)
        left.addView(sectionTitle("NIGHT VISION"))
        left.addView(card().apply {
            addView(text("Green screen filter", 13f, Color.WHITE, true))
            addView(text("Tap NV on the floating HUD to turn a subtle green tint on or off. This is a visual filter only; it does not detect enemies or reveal objects in games.", 10f, muted).apply { setPadding(0, dp(5), 0, 0) })
        })

        right.addView(sectionTitle("CROSSHAIR STUDIO"))
        right.addView(crosshairStudioCard())
        right.addView(sectionTitle("FPS MONITOR"))
        right.addView(card().apply {
            addView(text("FPS  ·  NOT EXPOSED", 15f, accent, true))
            addView(text("Android blocks ordinary apps from reading another game's live FPS. Nexon won't fake a number. FPS can be shown only if the phone's system gaming tools expose it to third-party apps.", 11f, muted).apply { setPadding(0, dp(6), 0, 0) })
        })
        right.addView(sectionTitle("YOUR GAMES"))
        right.addView(text("Refresh list", 11f, accent, true).apply { gravity = Gravity.END; setPadding(0, 0, 0, dp(7)); setOnClickListener { loadGames() } })
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.addView(gameList)
        right.addView(text("NEXON  •  v1.6", 10f, muted).apply { gravity = Gravity.END; setPadding(0, dp(12), 0, 0) })
    }

    private fun crosshairStudioCard(): LinearLayout {
        val container = card()
        val savedStyle = visualPrefs.getInt("crosshair_style", 0).coerceIn(0, 3)
        val savedColor = visualPrefs.getInt("crosshair_color", 0).coerceIn(0, CrosshairPalette.colors.lastIndex)
        val savedSize = visualPrefs.getInt("crosshair_size", 28).coerceIn(12, 48)
        val preview = CrosshairPreviewView(this).apply { setSettings(savedStyle, savedColor, savedSize) }
        container.addView(preview, LinearLayout.LayoutParams(-1, dp(82)).apply { bottomMargin = dp(8) })

        val optionsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val styleSpinner = Spinner(this)
        val styleAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOf("Classic", "Dot", "Ring", "Plus"))
        styleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        styleSpinner.adapter = styleAdapter
        styleSpinner.setSelection(savedStyle)
        optionsRow.addView(styleSpinner, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(5) })

        val colorSpinner = Spinner(this)
        val colorAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, CrosshairPalette.names)
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        colorSpinner.adapter = colorAdapter
        colorSpinner.setSelection(savedColor)
        optionsRow.addView(colorSpinner, LinearLayout.LayoutParams(0, dp(42), 1f))
        container.addView(optionsRow)

        var currentStyle = savedStyle
        var currentColor = savedColor
        var currentSize = savedSize
        fun applySettings() {
            preview.setSettings(currentStyle, currentColor, currentSize)
            visualPrefs.edit()
                .putInt("crosshair_style", currentStyle)
                .putInt("crosshair_color", currentColor)
                .putInt("crosshair_size", currentSize)
                .apply()
        }
        styleSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentStyle = position.coerceIn(0, 3); applySettings()
            }
        }
        colorSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentColor = position.coerceIn(0, CrosshairPalette.colors.lastIndex); applySettings()
            }
        }

        val sizeLabel = text("SIZE  ·  ${savedSize} dp", 10f, muted, true).apply { setPadding(0, dp(7), 0, 0) }
        container.addView(sizeLabel)
        val sizeSeek = SeekBar(this).apply { max = 36; progress = savedSize - 12 }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                currentSize = 12 + progress
                sizeLabel.text = "SIZE  ·  ${currentSize} dp"
                applySettings()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        container.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(32)))
        container.addView(text("Preview only inside Nexon. It will not appear over games.", 9f, muted))
        return container
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow display over other apps, then return and tap Enable again.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            Toast.makeText(this, "Nexon HUD started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Could not start HUD: ${e.message}", Toast.LENGTH_LONG).show() }
        updateOverlayStatus()
    }

    private fun updateOverlayStatus() {
        if (!::overlayStatus.isInitialized) return
        overlayStatus.text = if (Settings.canDrawOverlays(this)) "Overlay permission: allowed • Tap Enable to show HUD" else "Overlay permission: not granted"
    }

    private fun addStat(row: LinearLayout, label: String, initial: String): TextView {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), dp(9), dp(7), dp(9)); setBackgroundColor(panel) }
        row.addView(box, LinearLayout.LayoutParams(0, dp(66), 1f).apply { setMargins(0, 0, dp(7), dp(7)) })
        box.addView(text(label, 9f, muted, true))
        val value = text(initial, 17f, Color.WHITE, true).apply { setPadding(0, dp(5), 0, 0) }
        box.addView(value)
        return value
    }
    private fun sectionTitle(s: String) = text(s, 10f, muted, true).apply { setPadding(0, dp(7), 0, dp(7)); letterSpacing = 0.1f }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12)); setBackgroundColor(panel) }
    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }

    private fun refreshStats() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        ramValue.text = "${(mi.totalMem - mi.availMem) / (1024 * 1024)} MB"
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        tempValue.text = if (t >= 0) String.format("%.1f°C", t / 10f) else "N/A"
        networkValue.text = networkType()
        pingValue.text = OverlayService.latestPing?.let { "$it ms" } ?: "Testing…"
    }
    private fun networkType(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return "Offline"
        val c = cm.getNetworkCapabilities(n) ?: return "Offline"
        return when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }
    }
    @Suppress("DEPRECATION")
    private fun loadGames() {
        gameList.removeAllViews()
        val pm = packageManager
        // Query only apps that expose a launcher entry, instead of requesting the
        // broad QUERY_ALL_PACKAGES permission. This is enough for the game launcher.
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
            .mapNotNull { it.activityInfo?.applicationInfo }
            .distinctBy { it.packageName }
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        if (apps.isEmpty()) {
            gameList.addView(card().apply { addView(text("No launchable apps found.", 12f, Color.WHITE)); addView(text("Install a game, then refresh.", 10f, muted)) })
            return
        }
        apps.forEach { app ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(7), dp(8), dp(7)); setBackgroundColor(panel) }
            val icon = ImageView(this).apply { setImageDrawable(pm.getApplicationIcon(app)); scaleType = ImageView.ScaleType.FIT_CENTER }
            item.addView(icon, LinearLayout.LayoutParams(dp(30), dp(30)))
            item.addView(text(pm.getApplicationLabel(app).toString(), 11f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
            item.addView(text("OPEN", 10f, accent, true).apply { setPadding(dp(8), dp(7), dp(4), dp(7)); setOnClickListener { pm.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) } } })
            gameList.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
