package com.volt.gaming

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 14, 19)
    private val panel = Color.rgb(23, 27, 35)
    private val accent = Color.rgb(126, 156, 255)
    private val muted = Color.rgb(157, 166, 183)
    private lateinit var ramValue: TextView
    private lateinit var tempValue: TextView
    private lateinit var pingValue: TextView
    private lateinit var networkValue: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var gameList: LinearLayout
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            refreshStats()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        loadGames()
    }

    override fun onResume() {
        super.onResume()
        refreshStats()
        handler.removeCallbacks(refreshTask)
        handler.post(refreshTask)
        updateOverlayStatus()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refreshTask)
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(text("VOLT", 27f, Color.WHITE, true))
        top.addView(text("  GAMING", 12f, accent, true))
        page.addView(top)
        page.addView(text("Gaming tools that show real readings", 13f, muted).apply { setPadding(0, dp(5), 0, dp(20)) })

        page.addView(sectionTitle("LIVE DEVICE MONITOR"))
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ramValue = addStat(row1, "SYSTEM RAM USED", "—")
        tempValue = addStat(row1, "BATTERY TEMP", "—")
        pingValue = addStat(row2, "CLOUDFLARE TCP", "—")
        networkValue = addStat(row2, "NETWORK", "—")
        page.addView(row1); page.addView(row2)
        page.addView(text("RAM is device-wide. Ping measures a connection to Cloudflare (1.1.1.1), not your game's server. Battery temperature is not CPU temperature.", 11f, muted).apply { setPadding(0, dp(4), 0, 0) })

        page.addView(sectionTitle("FLOATING HUD"))
        val overlayCard = card()
        overlayCard.addView(text("Show monitoring over other apps", 15f, Color.WHITE, true))
        overlayCard.addView(text("A movable mini-panel with RAM, battery temperature, network and live connection latency.", 12f, muted).apply { setPadding(0, dp(7), 0, dp(12)) })
        val start = Button(this).apply {
            text = "ENABLE FLOATING HUD"
            setOnClickListener { enableOverlay() }
        }
        overlayCard.addView(start)
        val stop = Button(this).apply {
            text = "STOP FLOATING HUD"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)); updateOverlayStatus() }
        }
        overlayCard.addView(stop)
        overlayStatus = text("HUD status: checking…", 12f, accent, true).apply { setPadding(0, dp(8), 0, 0) }
        overlayCard.addView(overlayStatus)
        page.addView(overlayCard)

        page.addView(sectionTitle("FPS LIMITATION"))
        page.addView(card().apply {
            addView(text("FPS: not available", 17f, accent, true))
            addView(text("Android does not provide ordinary third-party apps with a universal API to read another game's live FPS. VOLT will not invent an FPS number. Use the phone's built-in game dashboard if it exposes FPS.", 12f, muted).apply { setPadding(0, dp(7), 0, 0) })
        })

        page.addView(sectionTitle("GAME LIBRARY"))
        page.addView(text("Refresh list", 12f, accent, true).apply {
            gravity = Gravity.END; setPadding(0, 0, 0, dp(10)); setOnClickListener { loadGames() }
        })
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(gameList)
        page.addView(text("VOLT Gaming  •  v1.2", 11f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(28), 0, 0) })
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(i)
            Toast.makeText(this, "Allow display over other apps, then return and tap Enable again.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            Toast.makeText(this, "VOLT HUD started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start HUD: ${e.message}", Toast.LENGTH_LONG).show()
        }
        updateOverlayStatus()
    }

    private fun updateOverlayStatus() {
        if (!::overlayStatus.isInitialized) return
        overlayStatus.text = if (Settings.canDrawOverlays(this)) "Overlay permission: allowed • Use Enable to show HUD" else "Overlay permission: not granted"
    }

    private fun addStat(row: LinearLayout, label: String, initial: String): TextView {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(15), dp(10), dp(15)); setBackgroundColor(panel) }
        val lp = LinearLayout.LayoutParams(0, dp(94), 1f).apply { setMargins(0, 0, dp(8), dp(8)) }
        row.addView(box, lp)
        box.addView(text(label, 10f, muted, true))
        val value = text(initial, 19f, Color.WHITE, true).apply { setPadding(0, dp(10), 0, 0) }
        box.addView(value)
        return value
    }

    private fun sectionTitle(s: String) = text(s, 11f, muted, true).apply { setPadding(0, dp(18), 0, dp(10)); letterSpacing = 0.12f }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); setBackgroundColor(panel) }
    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }

    private fun refreshStats() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val usedMb = (mi.totalMem - mi.availMem) / (1024 * 1024)
        ramValue.text = "${usedMb} MB"
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        tempValue.text = if (t >= 0) String.format("%.1f°C", t / 10f) else "N/A"
        networkValue.text = networkType()
        pingValue.text = OverlayService.latestPing?.let { "$it ms" } ?: "Testing…"
    }

    private fun networkType(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return "Offline"
        val c = cm.getNetworkCapabilities(n) ?: return "Offline"
        return when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }
    }

    @Suppress("DEPRECATION")
    private fun loadGames() {
        gameList.removeAllViews()
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        if (apps.isEmpty()) {
            gameList.addView(card().apply { addView(text("No launchable apps found.", 14f, Color.WHITE)); addView(text("Install a game, then tap Refresh list.", 12f, muted)) })
            return
        }
        apps.forEach { app ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(panel) }
            val icon = ImageView(this).apply { setImageDrawable(pm.getApplicationIcon(app)); scaleType = ImageView.ScaleType.FIT_CENTER }
            item.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
            item.addView(text(pm.getApplicationLabel(app).toString(), 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
            item.addView(text("OPEN", 11f, accent, true).apply { setPadding(dp(12), dp(9), dp(12), dp(9)); setOnClickListener { pm.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) } } })
            gameList.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
