package com.volt.gaming

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

/**
 * Display presets used by Nexon's full-screen tint overlay.
 * This is a transparent color veil, not pixel-by-pixel grading of the app underneath.
 */
object DisplayFilters {
    data class Preset(val name: String, val top: Int, val bottom: Int)

    val presets = listOf(
        Preset("Phosphor Green", Color.rgb(42, 255, 137), Color.rgb(0, 48, 29)),
        Preset("Emerald", Color.rgb(0, 220, 150), Color.rgb(0, 44, 42)),
        Preset("Lime Vision", Color.rgb(196, 255, 45), Color.rgb(45, 56, 0)),
        Preset("Amber Vision", Color.rgb(255, 190, 72), Color.rgb(75, 35, 0)),
        Preset("Thermal Blue", Color.rgb(65, 164, 255), Color.rgb(13, 28, 92)),
        Preset("Arctic Cyan", Color.rgb(60, 240, 255), Color.rgb(0, 53, 79)),
        Preset("Deep Violet", Color.rgb(179, 112, 255), Color.rgb(39, 9, 75)),
        Preset("Magenta", Color.rgb(255, 91, 208), Color.rgb(66, 0, 46)),
        Preset("Crimson", Color.rgb(255, 78, 87), Color.rgb(71, 0, 12)),
        Preset("Rose", Color.rgb(255, 145, 174), Color.rgb(76, 18, 44)),
        Preset("Sepia", Color.rgb(222, 165, 101), Color.rgb(62, 34, 12)),
        Preset("Moonlight", Color.rgb(205, 220, 255), Color.rgb(20, 31, 72)),
        Preset("Steel Blue", Color.rgb(123, 170, 205), Color.rgb(18, 37, 57)),
        Preset("Mono Silver", Color.rgb(235, 241, 246), Color.rgb(43, 49, 58)),
        Preset("White Phosphor", Color.rgb(250, 255, 235), Color.rgb(65, 78, 60)),
        Preset("Classic CRT", Color.rgb(110, 255, 130), Color.rgb(5, 38, 18)),
        Preset("Ruby Night", Color.rgb(255, 85, 105), Color.rgb(54, 5, 18)),
        Preset("Golden Dusk", Color.rgb(255, 211, 120), Color.rgb(82, 39, 5)),
        Preset("Ice Crystal", Color.rgb(178, 238, 255), Color.rgb(15, 49, 85)),
        Preset("Ocean Deep", Color.rgb(47, 190, 220), Color.rgb(4, 29, 65)),
        Preset("Cyber Purple", Color.rgb(206, 120, 255), Color.rgb(37, 7, 76)),
        Preset("Neon Orchid", Color.rgb(255, 115, 230), Color.rgb(69, 9, 73)),
        Preset("Forest Mist", Color.rgb(145, 220, 139), Color.rgb(14, 54, 34)),
        Preset("Copper Film", Color.rgb(235, 153, 103), Color.rgb(69, 29, 15)),
        Preset("Arctic Steel", Color.rgb(190, 220, 238), Color.rgb(25, 45, 68)),
        Preset("Sunset Glow", Color.rgb(255, 153, 99), Color.rgb(75, 18, 48)),
        Preset("Aqua Pulse", Color.rgb(95, 255, 220), Color.rgb(0, 48, 72)),
        Preset("Midnight Blue", Color.rgb(88, 127, 235), Color.rgb(10, 12, 53)),
        Preset("Soft Lavender", Color.rgb(223, 190, 255), Color.rgb(49, 31, 78)),
        Preset("Sandstone", Color.rgb(231, 202, 153), Color.rgb(72, 48, 27)),
        Preset("Graphite", Color.rgb(210, 220, 230), Color.rgb(25, 30, 39))
    )

    val names: List<String> get() = presets.map { it.name }

    fun drawTint(canvas: Canvas, width: Float, height: Float, index: Int, intensity: Int, paint: Paint) {
        if (width <= 0f || height <= 0f || intensity <= 0) return
        val preset = presets[index.coerceIn(presets.indices)]
        val strength = intensity.coerceIn(0, 100) / 100f
        val topAlpha = (28f + 62f * strength).toInt()
        val bottomAlpha = (18f + 48f * strength).toInt()
        val colors = intArrayOf(
            Color.argb((topAlpha * strength).toInt(), Color.red(preset.top), Color.green(preset.top), Color.blue(preset.top)),
            Color.argb((bottomAlpha * strength).toInt(), Color.red(preset.bottom), Color.green(preset.bottom), Color.blue(preset.bottom))
        )
        paint.shader = LinearGradient(0f, 0f, width * 0.12f, height, colors, null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width, height, paint)
        paint.shader = null

        // Subtle edge shading makes the tint less like a flat solid rectangle.
        val edgeAlpha = (10f * strength).toInt()
        if (edgeAlpha > 0) {
            paint.shader = RadialGradient(
                width / 2f, height / 2f, (width.coerceAtLeast(height) * 0.72f),
                intArrayOf(Color.TRANSPARENT, Color.argb(edgeAlpha, 0, 0, 0)), null, Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, width, height, paint)
            paint.shader = null
        }
    }
}

/** Landscape sample used to preview the same tint style in Nexon's settings. */
class DisplayFilterPreview(context: Context) : View(context) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var preset = 0
    private var intensity = 70

    fun setPreset(index: Int, amount: Int) {
        preset = index.coerceIn(DisplayFilters.presets.indices)
        intensity = amount.coerceIn(0, 100)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        fill.color = Color.rgb(18, 29, 48)
        canvas.drawRect(0f, 0f, w, h, fill)
        fill.color = Color.rgb(52, 81, 116)
        canvas.drawCircle(w * 0.78f, h * 0.24f, h * 0.13f, fill)
        fill.color = Color.rgb(91, 115, 104)
        val hill1 = android.graphics.Path().apply {
            moveTo(0f, h * 0.78f); lineTo(w * 0.23f, h * 0.43f)
            lineTo(w * 0.48f, h * 0.78f); close()
        }
        canvas.drawPath(hill1, fill)
        fill.color = Color.rgb(52, 89, 83)
        val hill2 = android.graphics.Path().apply {
            moveTo(w * 0.22f, h * 0.82f); lineTo(w * 0.58f, h * 0.42f)
            lineTo(w * 0.94f, h * 0.82f); close()
        }
        canvas.drawPath(hill2, fill)
        fill.color = Color.rgb(20, 38, 35)
        canvas.drawRect(0f, h * 0.8f, w, h, fill)
        for (i in 0..6) {
            val x = w * (0.06f + i * 0.145f)
            val base = h * (0.88f + (i % 2) * 0.04f)
            fill.color = Color.rgb(11, 25, 24)
            canvas.drawRect(x - h * 0.018f, base - h * 0.28f, x + h * 0.018f, base, fill)
            val tree = android.graphics.Path().apply {
                moveTo(x, base - h * 0.46f)
                lineTo(x - h * 0.12f, base - h * 0.18f)
                lineTo(x + h * 0.12f, base - h * 0.18f)
                close()
            }
            canvas.drawPath(tree, fill)
        }
        fill.color = Color.rgb(225, 232, 219)
        for (i in 0..13) {
            val x = (i * 47 % 101) / 101f * w
            val y = (i * 29 % 43) / 43f * h * 0.32f
            canvas.drawCircle(x, y, resources.displayMetrics.density, fill)
        }
        DisplayFilters.drawTint(canvas, w, h, preset, intensity, tintPaint)
    }
}

/** Full-screen tint view shown above another app. It intentionally does not capture touch input. */
class NightVisionOverlayView(context: Context) : View(context) {
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var preset = 0
    private var intensity = 70

    init { setBackgroundColor(Color.TRANSPARENT) }

    fun configure(index: Int, amount: Int) {
        preset = index.coerceIn(DisplayFilters.presets.indices)
        intensity = amount.coerceIn(0, 100)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        DisplayFilters.drawTint(canvas, width.toFloat(), height.toFloat(), preset, intensity, tintPaint)
    }
}
