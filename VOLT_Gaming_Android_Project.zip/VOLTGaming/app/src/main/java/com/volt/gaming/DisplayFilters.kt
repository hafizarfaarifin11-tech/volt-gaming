package com.volt.gaming

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.view.View

/** Display filters are intentionally applied only to Nexon's own UI, not to other apps. */
object DisplayFilters {
    val names = listOf("Night Green", "Monochrome", "High Contrast", "Cool", "Warm")

    private val identity = floatArrayOf(
        1f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )

    private val matrices = listOf(
        // Green-tinted luminance, with a mild lift to darker midtones.
        floatArrayOf(
            0.24f, 0.66f, 0.10f, 0f, 0f,
            0.28f, 0.76f, 0.12f, 0f, 12f,
            0.02f, 0.08f, 0.02f, 0f, -5f,
            0f, 0f, 0f, 1f, 0f
        ),
        // Standard luminance conversion.
        floatArrayOf(
            0.213f, 0.715f, 0.072f, 0f, 0f,
            0.213f, 0.715f, 0.072f, 0f, 0f,
            0.213f, 0.715f, 0.072f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ),
        floatArrayOf(
            1.35f, 0f, 0f, 0f, -28f,
            0f, 1.35f, 0f, 0f, -28f,
            0f, 0f, 1.35f, 0f, -28f,
            0f, 0f, 0f, 1f, 0f
        ),
        floatArrayOf(
            0.92f, 0f, 0f, 0f, -3f,
            0f, 1.00f, 0f, 0f, 2f,
            0f, 0f, 1.18f, 0f, 10f,
            0f, 0f, 0f, 1f, 0f
        ),
        floatArrayOf(
            1.14f, 0f, 0f, 0f, 8f,
            0f, 1.02f, 0f, 0f, 1f,
            0f, 0f, 0.82f, 0f, -7f,
            0f, 0f, 0f, 1f, 0f
        )
    )

    fun filter(index: Int, amount: Float): ColorMatrixColorFilter {
        val preset = matrices[index.coerceIn(matrices.indices)]
        val strength = amount.coerceIn(0f, 1f)
        val blended = FloatArray(20) { i ->
            identity[i] + (preset[i] - identity[i]) * strength
        }
        return ColorMatrixColorFilter(ColorMatrix(blended))
    }

    fun applyTo(view: View, enabled: Boolean, index: Int, amount: Float) {
        if (!enabled || amount <= 0f) {
            view.setLayerType(View.LAYER_TYPE_NONE, null)
            return
        }
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = filter(index, amount)
        }
        view.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
        view.invalidate()
    }
}

/** A small landscape sample so every preset can be previewed before enabling it. */
class DisplayFilterPreview(context: Context) : View(context) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val filterPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    fun setPreset(index: Int, amount: Float) {
        val preset = index.coerceIn(DisplayFilters.names.indices)
        filterPaint.colorFilter = DisplayFilters.filter(preset, amount.coerceIn(0f, 1f))
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val checkpoint = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), filterPaint)
        val w = width.toFloat()
        val h = height.toFloat()

        fill.color = Color.rgb(18, 29, 48)
        canvas.drawRect(0f, 0f, w, h, fill)
        fill.color = Color.rgb(52, 81, 116)
        canvas.drawCircle(w * 0.78f, h * 0.24f, h * 0.13f, fill)
        fill.color = Color.rgb(91, 115, 104)
        val hill1 = android.graphics.Path().apply {
            moveTo(0f, h * 0.78f); lineTo(w * 0.23f, h * 0.43f)
            lineTo(w * 0.48f, h * 0.78f); close()
        }
        canvas.drawPath(hill1, fill)
        fill.color = Color.rgb(52, 89, 83)
        val hill2 = android.graphics.Path().apply {
            moveTo(w * 0.22f, h * 0.82f); lineTo(w * 0.58f, h * 0.42f)
            lineTo(w * 0.94f, h * 0.82f); close()
        }
        canvas.drawPath(hill2, fill)
        fill.color = Color.rgb(20, 38, 35)
        canvas.drawRect(0f, h * 0.8f, w, h, fill)
        fill.color = Color.rgb(13, 25, 25)
        for (i in 0..6) {
            val x = w * (0.06f + i * 0.145f)
            val base = h * (0.88f + (i % 2) * 0.04f)
            fill.color = Color.rgb(11, 25, 24)
            canvas.drawRect(x - h * 0.018f, base - h * 0.28f, x + h * 0.018f, base, fill)
            val tree = android.graphics.Path().apply {
                moveTo(x, base - h * 0.46f)
                lineTo(x - h * 0.12f, base - h * 0.18f)
                lineTo(x + h * 0.12f, base - h * 0.18f)
                close()
            }
            canvas.drawPath(tree, fill)
        }
        fill.color = Color.rgb(225, 232, 219)
        for (i in 0..13) {
            val x = (i * 47 % 101) / 101f * w
            val y = (i * 29 % 43) / 43f * h * 0.32f
            canvas.drawCircle(x, y, (resources.displayMetrics.density * 0.9f), fill)
        }
        canvas.restoreToCount(checkpoint)
    }
}
