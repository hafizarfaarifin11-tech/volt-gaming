package com.volt.gaming

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.*
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.volt.gaming.START_HUD"
        private const val CHANNEL = "volt_hud"
        private const val NOTIFICATION_ID = 1101
        @Volatile var latestPing: Int? = null
    }
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private lateinit var ramText: TextView
    private lateinit var tempText: TextView
    private lateinit var pingText: TextView
    private lateinit var netText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastTotal = 0L
    private val tick = object : Runnable {
        override fun run() {
            updateLocalMetrics()
            probePing()
            handler.postDelayed(this, 2500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("VOLT Gaming HUD active")
            .setContentText("RAM • battery temperature • network latency")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay == null) showOverlay()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun showOverlay() {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.argb(235, 17, 21, 29))
        }
        val header = TextView(this).apply {
            text = "VOLT HUD   ⋮"
            textSize = 12f
            setTextColor(Color.rgb(126, 156, 255))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(6))
        }
        root.addView(header)
        ramText = metric("RAM: reading…")
        tempText = metric("BATTERY: reading…")
        pingText = metric("PING: testing…")
        netText = metric("NETWORK: checking…")
        root.addView(ramText); root.addView(tempText); root.addView(pingText); root.addView(netText)
        val close = TextView(this).apply {
            text = "STOP HUD"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(7), 0, 0)
            setOnClickListener { stopSelf() }
        }
        root.addView(close)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(dp(190), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12); y = dp(120)
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX - (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); try { wm.updateViewLayout(root, params) } catch (_: Exception) {}; true }
                else -> true
            }
        }
        wm.addView(root, params)
        overlay = root
    }

    private fun metric(s: String) = TextView(this).apply { text = s; textSize = 11f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setPadding(0, 0, 0,  dp(4)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun updateLocalMetrics() {
        if (overlay == null) return
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo(); am.getMemoryInfo(info)
        val used = (info.totalMem - info.availMem) / (1024 * 1024)
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val temp = if (rawTemp >= 0) String.format("%.1f°C", rawTemp / 10f) else "N/A"
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val net = cm.activeNetwork
        val caps = if (net != null) cm.getNetworkCapabilities(net) else null
        val network = when {
            caps == null -> "Offline"
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            else -> "Connected"
        }
        ramText.text = "RAM used: ${used} MB"
        tempText.text = "Battery: $temp"
        pingText.text = "Cloudflare TCP: ${latestPing?.let { "$it ms" } ?: "testing…"}"
        netText.text = "Network: $network"
    }

    private fun probePing() {
        executor.execute {
            val ms = try {
                val start = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1800) }
                ((System.nanoTime() - start) / 1_000_000).toInt()
            } catch (_: Exception) { null }
            latestPing = ms
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "VOLT Floating HUD", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        executor.shutdownNow()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlay = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
