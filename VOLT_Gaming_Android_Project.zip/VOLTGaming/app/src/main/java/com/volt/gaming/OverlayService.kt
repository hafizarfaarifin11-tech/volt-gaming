package com.volt.gaming

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.net.Uri
import android.view.*
import android.widget.*
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.math.max

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.volt.gaming.START_HUD"
        const val ACTION_EDIT_MACRO = "com.volt.gaming.EDIT_MACRO"
        const val ACTION_STOP_MACRO = "com.volt.gaming.STOP_MACRO"
        private const val CHANNEL = "nexon_hud"
        private const val NOTIFICATION_ID = 1101
        private const val PREFS = "nexon_macro"
        @Volatile var latestPing: Int? = null
    }

    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var editorOverlay: View? = null
    private var macroTrigger: TextView? = null
    private var macroHeld = false
    private lateinit var ramText: TextView
    private lateinit var tempText: TextView
    private lateinit var pingText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    private val tick = object : Runnable {
        override fun run() {
            updateLocalMetrics()
            probePing()
            handler.postDelayed(this, 2500)
        }
    }

    private val macroTick = object : Runnable {
        override fun run() {
            if (!macroHeld) return
            val accessibility = MacroAccessibilityService.instance
            if (accessibility == null) {
                macroHeld = false
                Toast.makeText(this@OverlayService, "Enable Nexon Macro in Accessibility settings first.", Toast.LENGTH_LONG).show()
                return
            }
            val size = displaySize()
            val nx = prefs.getFloat("target_x", 0.62f).coerceIn(0.02f, 0.98f)
            val ny = prefs.getFloat("target_y", 0.55f).coerceIn(0.02f, 0.98f)
            accessibility.tapAt(nx * size.x, ny * size.y)
            handler.postDelayed(this, prefs.getInt("interval_ms", 180).toLong().coerceIn(100L, 1000L))
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Nexon HUD active")
            .setContentText("RAM • battery temperature • network latency")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_EDIT_MACRO -> showMacroEditor()
            ACTION_STOP_MACRO -> stopMacro()
            else -> {
                if (overlay == null) showOverlay()
                handler.removeCallbacks(tick)
                handler.post(tick)
                if (prefs.getBoolean("macro_enabled", false)) showMacroTrigger()
            }
        }
        return START_STICKY
    }

    private fun showOverlay() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), dp(7), dp(7), dp(7))
            background = GradientDrawable().apply {
                setColor(Color.argb(224, 12, 16, 25))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.argb(170, 93, 126, 220))
            }
            elevation = dp(8).toFloat()
        }

        val brand = TextView(this).apply {
            text = "N"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(126, 156, 255))
            gravity = Gravity.CENTER
            setBackgroundColor(Color.TRANSPARENT)
        }
        root.addView(brand, LinearLayout.LayoutParams(dp(23), dp(32)))
        val separator = View(this).apply { setBackgroundColor(Color.argb(100, 140, 155, 190)) }
        root.addView(separator, LinearLayout.LayoutParams(dp(1), dp(25)).apply { marginStart = dp(5); marginEnd = dp(5) })

        val ram = metricCell("▦", "RAM", "…", 59)
        val temp = metricCell("♨", "TEMP", "…", 54)
        val ping = metricCell("⌁", "PING", "…", 55)
        val fps = metricCell("◉", "FPS", "N/A", 47)
        ramText = ram.second
        tempText = temp.second
        pingText = ping.second
        // Android does not expose other apps' live game FPS to ordinary third-party apps.
        listOf(ram.first, temp.first, ping.first, fps.first).forEach { cell ->
            root.addView(cell, LinearLayout.LayoutParams(dp(cell.tag as Int), dp(36)))
        }

        val macroButton = actionBubble("+") {
            try {
                startService(Intent(this, OverlayService::class.java).setAction(ACTION_EDIT_MACRO))
            } catch (_: Exception) {
                Toast.makeText(this, "Could not open Macro editor.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(macroButton, LinearLayout.LayoutParams(dp(27), dp(32)).apply { marginStart = dp(3) })

        val close = actionBubble("×") { stopSelf() }
        root.addView(close, LinearLayout.LayoutParams(dp(25), dp(34)))

        val type = overlayWindowType()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(120)
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        brand.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
                    true
                }
                else -> true
            }
        }

        wm.addView(root, params)
        overlay = root
    }

    private fun actionBubble(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = if (label == "+") 19f else 20f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (label == "+") Color.rgb(126, 156, 255) else Color.rgb(190, 199, 220))
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.argb(65, 126, 156, 255))
            cornerRadius = dp(9).toFloat()
            setStroke(dp(1), Color.argb(110, 126, 156, 255))
        }
        setOnClickListener { action() }
    }

    private fun metricCell(symbol: String, label: String, initial: String, widthDp: Int): Pair<LinearLayout, TextView> {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            tag = widthDp
            setPadding(dp(1), 0, dp(1), 0)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        top.addView(TextView(this).apply {
            text = symbol
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(126, 156, 255))
        })
        top.addView(TextView(this).apply {
            text = " $label"
            textSize = 8f
            letterSpacing = 0.04f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(150, 161, 184))
        })
        val value = TextView(this).apply {
            text = initial
            textSize = 10f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 1
        }
        cell.addView(top)
        cell.addView(value)
        return cell to value
    }

    private fun showMacroEditor() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow display over other apps first.", Toast.LENGTH_LONG).show()
            return
        }
        removeMacroTrigger()
        removeEditor()

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.argb(205, 4, 7, 13)) }
        val topInfo = TextView(this).apply {
            text = "NEXON DUAL MACRO  •  DRAG BOTH CIRCLES"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = panelBackground()
        }
        frame.addView(topInfo, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(12)
        })

        val savedSize = prefs.getInt("trigger_size_dp", 104).coerceIn(64, 140)
        val trigger = circleLabel("1\nTRIGGER", savedSize, Color.argb(92, 48, 121, 255), Color.rgb(103, 166, 255))
        val target = circleLabel("2\nTAP", 52, Color.argb(105, 255, 155, 67), Color.rgb(255, 181, 94))
        frame.addView(trigger, FrameLayout.LayoutParams(dp(savedSize), dp(savedSize)))
        frame.addView(target, FrameLayout.LayoutParams(dp(52), dp(52)))

        val prefsX1 = prefs.getFloat("trigger_x", 0.80f)
        val prefsY1 = prefs.getFloat("trigger_y", 0.48f)
        val prefsX2 = prefs.getFloat("target_x", 0.62f)
        val prefsY2 = prefs.getFloat("target_y", 0.53f)
        frame.post {
            trigger.x = (frame.width * prefsX1 - trigger.width / 2f).coerceIn(0f, (frame.width - trigger.width).toFloat())
            trigger.y = (frame.height * prefsY1 - trigger.height / 2f).coerceIn(0f, (frame.height - trigger.height).toFloat())
            target.x = (frame.width * prefsX2 - target.width / 2f).coerceIn(0f, (frame.width - target.width).toFloat())
            target.y = (frame.height * prefsY2 - target.height / 2f).coerceIn(0f, (frame.height - target.height).toFloat())
        }
        makeDraggable(trigger, frame)
        makeDraggable(target, frame)

        val controlPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = panelBackground()
        }
        val sizeValue = TextView(this).apply { text = "Trigger size: ${savedSize}dp"; textSize = 10f; setTextColor(Color.WHITE) }
        val sizeSeek = SeekBar(this).apply {
            max = 76
            progress = savedSize - 64
        }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val newSize = 64 + progress
                sizeValue.text = "Trigger size: ${newSize}dp"
                val lp = trigger.layoutParams as FrameLayout.LayoutParams
                val oldCenterX = trigger.x + trigger.width / 2f
                val oldCenterY = trigger.y + trigger.height / 2f
                lp.width = dp(newSize); lp.height = dp(newSize)
                trigger.layoutParams = lp
                trigger.x = (oldCenterX - trigger.width / 2f).coerceIn(0f, (frame.width - trigger.width).toFloat())
                trigger.y = (oldCenterY - trigger.height / 2f).coerceIn(0f, (frame.height - trigger.height).toFloat())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        val intervalValue = TextView(this).apply { text = "Tap interval: ${prefs.getInt("interval_ms", 180)}ms"; textSize = 10f; setTextColor(Color.WHITE) }
        val intervalSeek = SeekBar(this).apply {
            max = 900
            progress = (prefs.getInt("interval_ms", 180) - 100).coerceIn(0, 900)
        }
        intervalSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                intervalValue.text = "Tap interval: ${100 + progress}ms"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        controlPanel.addView(sizeValue)
        controlPanel.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(30)))
        controlPanel.addView(intervalValue)
        controlPanel.addView(intervalSeek, LinearLayout.LayoutParams(-1, dp(30)))

        val buttonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val save = panelButton("SAVE & ENABLE", Color.rgb(126, 156, 255)) {
            val w = max(1, frame.width).toFloat()
            val h = max(1, frame.height).toFloat()
            prefs.edit()
                .putFloat("trigger_x", ((trigger.x + trigger.width / 2f) / w).coerceIn(0.02f, 0.98f))
                .putFloat("trigger_y", ((trigger.y + trigger.height / 2f) / h).coerceIn(0.02f, 0.98f))
                .putFloat("target_x", ((target.x + target.width / 2f) / w).coerceIn(0.02f, 0.98f))
                .putFloat("target_y", ((target.y + target.height / 2f) / h).coerceIn(0.02f, 0.98f))
                .putInt("trigger_size_dp", 64 + sizeSeek.progress)
                .putInt("interval_ms", 100 + intervalSeek.progress)
                .putBoolean("macro_enabled", true)
                .apply()
            removeEditor()
            showMacroTrigger()
            Toast.makeText(this, "Macro saved. Hold the blue trigger circle to tap the orange target.", Toast.LENGTH_LONG).show()
            if (MacroAccessibilityService.instance == null) openAccessibilitySettings()
        }
        val stop = panelButton("STOP", Color.rgb(255, 112, 112)) { stopMacro(); Toast.makeText(this, "Macro stopped", Toast.LENGTH_SHORT).show() }
        val cancel = panelButton("CANCEL", Color.rgb(178, 188, 207)) {
            removeEditor()
            if (prefs.getBoolean("macro_enabled", false)) showMacroTrigger()
        }
        buttonRow.addView(save, LinearLayout.LayoutParams(0, dp(39), 1f).apply { rightMargin = dp(6) })
        buttonRow.addView(stop, LinearLayout.LayoutParams(0, dp(39), 0.55f).apply { rightMargin = dp(6) })
        buttonRow.addView(cancel, LinearLayout.LayoutParams(0, dp(39), 0.65f))
        controlPanel.addView(buttonRow)
        frame.addView(controlPanel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            leftMargin = dp(10); rightMargin = dp(10); bottomMargin = dp(10)
        })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try {
            wm.addView(frame, params)
            editorOverlay = frame
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open Macro editor: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun circleLabel(label: String, sizeDp: Int, fill: Int, stroke: Int): TextView = TextView(this).apply {
        text = label
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            setStroke(dp(2), stroke)
        }
        elevation = dp(8).toFloat()
        contentDescription = label.replace('\n', ' ')
    }

    private fun makeDraggable(view: View, parent: FrameLayout) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> true
                MotionEvent.ACTION_MOVE -> {
                    val loc = IntArray(2)
                    parent.getLocationOnScreen(loc)
                    v.x = (event.rawX - loc[0] - v.width / 2f).coerceIn(0f, max(0, parent.width - v.width).toFloat())
                    v.y = (event.rawY - loc[1] - v.height / 2f).coerceIn(0f, max(0, parent.height - v.height).toFloat())
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
    }

    private fun panelButton(label: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(color)
        background = GradientDrawable().apply {
            setColor(Color.argb(30, 255, 255, 255))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.argb(150, color.red(), color.green(), color.blue()))
        }
        setOnClickListener { action() }
    }

    private fun panelBackground() = GradientDrawable().apply {
        setColor(Color.argb(245, 17, 22, 34))
        cornerRadius = dp(14).toFloat()
        setStroke(dp(1), Color.argb(175, 97, 127, 204))
    }

    private fun Int.red() = (this shr 16) and 0xff
    private fun Int.green() = (this shr 8) and 0xff
    private fun Int.blue() = this and 0xff

    private fun showMacroTrigger() {
        if (macroTrigger != null || !prefs.getBoolean("macro_enabled", false)) return
        if (!Settings.canDrawOverlays(this)) return
        val display = displaySize()
        val sizeDp = prefs.getInt("trigger_size_dp", 104).coerceIn(64, 140)
        val sizePx = dp(sizeDp)
        val cx = (prefs.getFloat("trigger_x", 0.80f) * display.x).toInt()
        val cy = (prefs.getFloat("trigger_y", 0.48f) * display.y).toInt()
        val trigger = TextView(this).apply {
            text = "HOLD\nMACRO"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(95, 48, 121, 255))
                setStroke(dp(2), Color.argb(230, 103, 166, 255))
            }
            elevation = dp(10).toFloat()
        }
        val params = WindowManager.LayoutParams(
            sizePx, sizePx, overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (cx - sizePx / 2).coerceIn(0, max(0, display.x - sizePx))
            y = (cy - sizePx / 2).coerceIn(0, max(0, display.y - sizePx))
        }
        trigger.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (MacroAccessibilityService.instance == null) {
                        Toast.makeText(this, "Enable Nexon Macro in Accessibility settings first.", Toast.LENGTH_LONG).show()
                        openAccessibilitySettings()
                    } else {
                        macroHeld = true
                        handler.removeCallbacks(macroTick)
                        handler.post(macroTick)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    macroHeld = false
                    handler.removeCallbacks(macroTick)
                    true
                }
                else -> true
            }
        }
        try {
            wm.addView(trigger, params)
            macroTrigger = trigger
        } catch (_: Exception) {
            Toast.makeText(this, "Could not show macro trigger.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            Toast.makeText(this, "Open Settings → Accessibility → Downloaded apps → Nexon Macro.", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopMacro() {
        macroHeld = false
        handler.removeCallbacks(macroTick)
        prefs.edit().putBoolean("macro_enabled", false).apply()
        removeMacroTrigger()
        removeEditor()
    }

    private fun removeMacroTrigger() {
        macroHeld = false
        handler.removeCallbacks(macroTick)
        try { macroTrigger?.let { wm.removeView(it) } } catch (_: Exception) {}
        macroTrigger = null
    }

    private fun removeEditor() {
        try { editorOverlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        editorOverlay = null
    }

    private fun overlayWindowType() = if (Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun displaySize(): Point {
        val point = Point()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealSize(point)
        return point
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun updateLocalMetrics() {
        if (overlay == null) return
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo(); am.getMemoryInfo(info)
        val used = (info.totalMem - info.availMem) / (1024 * 1024)
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val temp = if (rawTemp >= 0) String.format("%.1f°", rawTemp / 10f) else "N/A"
        ramText.text = "${used}MB"
        tempText.text = temp
        pingText.text = latestPing?.let { "${it}ms" } ?: "…"
    }

    private fun probePing() {
        executor.execute {
            val ms = try {
                val start = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1800) }
                ((System.nanoTime() - start) / 1_000_000).toInt()
            } catch (_: Exception) { null }
            latestPing = ms
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Nexon Floating HUD", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        macroHeld = false
        handler.removeCallbacks(tick)
        handler.removeCallbacks(macroTick)
        executor.shutdownNow()
        removeMacroTrigger()
        removeEditor()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
