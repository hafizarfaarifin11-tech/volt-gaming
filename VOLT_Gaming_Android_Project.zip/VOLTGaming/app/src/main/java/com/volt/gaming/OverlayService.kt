package com.volt.gaming

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.volt.gaming.START_HUD"
        private const val CHANNEL = "nexon_hud"
        private const val NOTIFICATION_ID = 1101
        @Volatile var latestPing: Int? = null
    }

    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private lateinit var ramText: TextView
    private lateinit var tempText: TextView
    private lateinit var pingText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    private val tick = object : Runnable {
        override fun run() {
            updateLocalMetrics()
            probePing()
            handler.postDelayed(this, 2500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Nexon HUD active")
            .setContentText("RAM • battery temperature • network latency")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay == null) showOverlay()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun showOverlay() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), dp(7), dp(7), dp(7))
            background = GradientDrawable().apply {
                setColor(Color.argb(224, 12, 16, 25))
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.argb(170, 93, 126, 220))
            }
            elevation = dp(8).toFloat()
        }

        val brand = TextView(this).apply {
            text = "N"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(126, 156, 255))
            gravity = Gravity.CENTER
            setBackgroundColor(Color.TRANSPARENT)
        }
        root.addView(brand, LinearLayout.LayoutParams(dp(23), dp(32)))
        val separator = View(this).apply { setBackgroundColor(Color.argb(100, 140, 155, 190)) }
        root.addView(separator, LinearLayout.LayoutParams(dp(1), dp(25)).apply { marginStart = dp(5); marginEnd = dp(5) })

        val ram = metricCell("▦", "RAM", "…", 59)
        val temp = metricCell("♨", "TEMP", "…", 54)
        val ping = metricCell("⌁", "PING", "…", 55)
        val fps = metricCell("◉", "FPS", "N/A", 47)
        ramText = ram.second
        tempText = temp.second
        pingText = ping.second
        // Android does not expose other apps' live game FPS to ordinary third-party apps.
        listOf(ram.first, temp.first, ping.first, fps.first).forEach { cell ->
            root.addView(cell, LinearLayout.LayoutParams(dp(cell.tag as Int), dp(36)))
        }

        val close = actionBubble("×") { stopSelf() }
        root.addView(close, LinearLayout.LayoutParams(dp(25), dp(34)))

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(120)
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        brand.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
                    true
                }
                else -> true
            }
        }

        wm.addView(root, params)
        overlay = root
    }

    private fun actionBubble(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 20f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(190, 199, 220))
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.argb(65, 126, 156, 255))
            cornerRadius = dp(9).toFloat()
            setStroke(dp(1), Color.argb(110, 126, 156, 255))
        }
        setOnClickListener { action() }
    }

    private fun metricCell(symbol: String, label: String, initial: String, widthDp: Int): Pair<LinearLayout, TextView> {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            tag = widthDp
            setPadding(dp(1), 0, dp(1), 0)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        top.addView(TextView(this).apply {
            text = symbol
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(126, 156, 255))
        })
        top.addView(TextView(this).apply {
            text = " $label"
            textSize = 8f
            letterSpacing = 0.04f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(150, 161, 184))
        })
        val value = TextView(this).apply {
            text = initial
            textSize = 10f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 1
        }
        cell.addView(top)
        cell.addView(value)
        return cell to value
    }

    private fun overlayWindowType() = if (Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun updateLocalMetrics() {
        if (overlay == null) return
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo(); am.getMemoryInfo(info)
        val used = (info.totalMem - info.availMem) / (1024 * 1024)
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val temp = if (rawTemp >= 0) String.format("%.1f°", rawTemp / 10f) else "N/A"
        ramText.text = "${used}MB"
        tempText.text = temp
        pingText.text = latestPing?.let { "${it}ms" } ?: "…"
    }

    private fun probePing() {
        executor.execute {
            val ms = try {
                val start = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1800) }
                ((System.nanoTime() - start) / 1_000_000).toInt()
            } catch (_: Exception) { null }
            latestPing = ms
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Nexon Floating HUD", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        executor.shutdownNow()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
